<?php
/**
 * zNoSQL
 *
 * Processa as tags zNoSQL
 *
 * @package ztag
 * @subpackage template
 * @category help
 * @version $Revision$
 * @author Ruben Zevallos Jr. <zevallos@zevallos.com.br>
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link http://ztag.zyc.com.br
 * @copyright 2007-2010 by Ruben Zevallos(r) Jr.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * This software consists of voluntary contributions made by many individuals
 * and is licensed under the LGPL. For more information, see
 * <http://ztag.zyc.com.br> *
 */

define("znosqlVersion", 1.0, 1);
define("znosqlVersionSufix", "ALFA 0.1", 1);
/**
 * Constants for future NoSQL driver manager
 */
define("nosqlMongo", "Mongo", 1);

/**#@+
 * Define the nosqlHandle structure
 */
define("nosqlHandleDriver",          0, 1);
define("nosqlHandleId",              1, 1);
define("nosqlHandleHost",            2, 1);
define("nosqlHandleDatabaseName",    3, 1);
define("nosqlHandleUser",            4, 1);
define("nosqlHandlePassword",        5, 1);
define("nosqlHandlePort",            6, 1);
define("nosqlHandleCollectionName",  7, 1);
define("nosqlHandleState",           8, 1);
define("nosqlHandleDatabase",        9, 1);
define("nosqlHandleCollection",     10, 1);

/**#@+
 * Define nosqlHandle state
 */
define("nosqlHandleStateOpen",   1, 1);
define("nosqlHandleStateClosed", 0, 1);

/**
 * Just to check if zTag was loaded
 *
 * <code>
 * znosql_exist();
 * </code>
 *
 * @return boolean 1 if exist
 *
 * @since 1.0
 */
function znosql_exist() {
  return 1;
}

/**
 * Return this zTag version
 *
 * <code>
 * znosql_version();
 * </code>
 *
 * @return string with zTag version
 *
 * @since 1.0
 */
function znosql_version() {
  return znosqlVersion." ".znosqlVersionSufix;
}

/**
 * Compare the version parameter with current version
 *
 * <code>
 * znosql_compare();
 * </code>
 *
 * @param number $version the version to compare
 *
 * @return boolean true if match with current version
 *
 * @since 1.0
 */
function znosql_compare($version) {
  return znosqlVersion === $version;
}

/**
 * Main zTag functions selector
 *
 * <code>
 * znosql_execute($tagId, $tagFunction, $arrayTag, $arrayTagId, $arrayOrder);
 * </code>
 *
 * @param integer $tagId array id of current zTag of $arrayTag array
 * @param string $tagFunction name of zTag function
 * @param array $arrayTag array with all compiled zTags
 * @param array $arrayTagId array with all Ids values
 * @param array $arrayOrder array with zTag executing order
 *
 * @since 1.0
 */
function znosql_zexecute($tagId, $tagFunction, &$arrayTag, &$arrayTagId, $arrayOrder) {
  $arrParam = $arrayTag[$tagId][ztagParam];

  $strUse        = $arrParam["use"];
  $strDatabase   = $arrParam["database"];
  $strCollection = $arrParam["collection"];
  
  $strValue     = $arrParam["value"];
  $strVar       = $arrParam["var"];
  $strTransform = $arrParam["transform"];

  if ($arrayTag[$tagId][ztagContentWidth]) $strContent = $arrayTag[$tagId][ztagContent];

  $errorMessage = "";

  switch (strtolower($tagFunction)) {
    /*+
     * <znosql:open id="mongoDB" driver="Mongo" host="username:password@mongodb.zyc.com.br:27017" database="Direito2" collection="pubPaginas" />
     * <znosql:open id="mongoDB" driver="Mongo" host="mongodb.zyc.com.br" username="username" password="password" port="27017" database="Direito2" collection="pubPaginas" />
     * 
     * Open connection to a NoSQL Server
     *
     * id="mongoDB" 
     * driver="Mongo" 
     * host="username:password@mongodb.zyc.com.br:27017" <-- mongodb://[username:password@]host1[:port1][,host2[:port2:],...] 
     * username="username"
     * password="password"
     * port=""27017"
     * options="option=value;option2=value2" 
     * database="Direito2" 
     * collection="pubPaginas"
     * persist="0|1|true|false|x"
     */  	
    case "open":
      $strId         = $arrParam["id"];
    	
      $strDriver     = $arrParam["driver"];
    	$strHost       = $arrParam["host"];

      $strUsername   = $arrParam["username"];
      $strPassword   = $arrParam["password"];
      $strPort       = $arrParam["port"];
      $strPersist    = $arrParam["persist"];
      $strOptions    = $arrParam["options"];
      
      ztagReturnConstant($strHost);
      ztagReturnConstant($strDatabase);
      ztagReturnConstant($strUsername);
      ztagReturnConstant($strPassword);
      ztagReturnConstant($strPort);
      
    	$errorMessage .= ztagParamCheck($arrParam, "id,driver,host");

      $strDriver = constant("nosql$strDriver");
      
      if ($strUsername && $strPassword) $strHost = "$strUsername:$strPassword@$strHost";
      if ($strPort) $strHost = "$strHost:$strPort";
      if ($strOptions) $strHost = "$strHost?$strOptions";
      
    	if (extension_loaded('mongo')) {
        try {
        	$nosqlHandle = Array();
        	
        	if ($strPersist === "true" || $strPersist === "1" || $strPersist ="x") {
            $dbHandle = new  Mongo($strHost, array("persist" => "x"));
        	} else {
            $dbHandle = new  Mongo($strHost);
        	}
          
          if ($strDatabase) $nosqlDB = $nosqlHandle->selectDB($strDatabase);
          
        } catch(MongoConnectionException $e) {
          $errorMessage .= "<br />Cannot connect to $strDriver (".$e->getMessage().")[".$dbHandle->getLastError()."]";
        }
        
        if ($strCollection) $nosqlColection = $nosqlDB->selectCollection($strCollection);
      
    	} else {
    		$errorMessage .= "<br />$strDriver extention is not installed!";
    	}

			// Set all NoSQL handler structure
			$nosqlHandle[nosqlHandleDriver]   = $strDriver;
			
			$nosqlHandle[nosqlHandleHost]         = $strHost;
			$nosqlHandle[nosqlHandleDatabaseName] = $dbDatabase;
			$nosqlHandle[nosqlHandleUser]         = $strUsername;
			$nosqlHandle[nosqlHandlePassword]     = $strPassword;
			$nosqlHandle[nosqlHandlePort]         = $strPort;
			
			$nosqlHandle[nosqlHandleId]           = $dbHandle;
			
			$nosqlHandle[nosqlHandleState]        = dbHandleStateOpen;
			
      $arrayTagId[$strId][ztagIdHandle]     = $nosqlHandle;
      $arrayTagId[$strId][ztagIdType]       = idTypeNoSQL;
      $arrayTagId[$strId][ztagIdState]      = idStateOpened;			
    	break;

    /*+
     * <znosql:insert use="mongoDB">
     *  pagCodigo="1"
     *  , pagNome="Page \"title\""
     *  , pagResumo='Page \'resume\''
     *  , pagDescricao:"Page body"
     *  , pagPalavrasChave:{"example","NoSQL"}
		 *  , pagInclusao='2010/10/10'
		 *  , pagAtivo=1
     * </znosql:insert>
     *
     * <znosql:insert use="mongoDB" value="$varInsert" />
     * 
     * Do an Insert in currente Connection
     */ 
    case "insert":
      $errorMessage .= ztagParamCheck($arrParam, "use");

      if ($strContent) $contentArray = $strContent;

      if ($strValue) $contentArray = $strValue;

      if ($contentArray) $contentArray = ztagVars($contentArray, $arrayTagId);
      
      if (!$strContent && !$strValue) $errorMessage .= ztagParamCheck($arrParam, "value");
      
      if ($strTransform && $contentArray) $contentArray = ztagTransform($contentArray, $strTransform);

      $contentArray = preg_replace("/\t/", "  ", $contentArray);
      $contentArray = ltrim($contentArray, "\r\n");
      $contentArray = rtrim($contentArray, "\r\n");
      
      preg_match_all("%(\s*|\s*,\s*)(?P<param>\s*?\w+\s*[=:]\s*)((?P<value>\"(?:\\\"|[^\\\"\n])*?\"|\w+|'(?:\\'|[^\\'\n])*?')|(?P<array>\{(?:\\\"|[^\\\{\n])*?\}))%sm", $contentArray, $Matches, PREG_OFFSET_CAPTURE);
      
      $contentArray = array();

      foreach ($Matches[0] as $key => $value) {
      	$paramKey   = $Matches["param"][$key][0];
      	$paramValue = $Matches["value"][$key][0];
        $paramArray = $Matches["array"][$key][0];
      	
		    if (substr($paramKey, 0, 1) === " ") $paramKey = substr($paramKey, 1, strlen($paramKey));
		    if (substr($paramKey, strlen($paramKey)-1, 1) === "=" || substr($paramKey, strlen($paramKey)-1, 1) === ":") $paramKey = substr($paramKey, 0, strlen($paramKey) - 1);
		
		    if (substr($paramValue, 0, 1) === "\"" || substr($paramValue, 0, 1) === "\'") $paramValue = substr($paramValue, 1, strlen($paramValue) - 2);
      	
        if ($paramValue) {
        	$contentArray[$strParam] = $paramValue;
        	
        } elseif ($paramArray) {
        	// Generate array
        }
      }
      //collection->insert($f);

	    $arrayTagId[$strLocalId][ztagIdValue]  = $strContent;
	    $arrayTagId[$strLocalId][ztagIdLength] = strlen($strContent);
	
	    $arrayTagId[$strLocalId][ztagIdType]   = idTypeFetch;
	
	    $arrayTagId[$strLocalId][ztagIdHandle] = $arrayTagId[$strUse][ztagIdHandle];
      
      break;
    	
    /*+
     * <znosql:get use="mongoDB">
     *   Commands
     * </znosql:execute>
     * 
     * Execute a NoSQL commands
     */ 
    case "get":
      $errorMessage .= ztagParamCheck($arrParam, "use");
	    $cursor = $this->collection->find($f);
	
	    $k = array();
	    $i = 0;
	
	    while( $cursor->hasNext())
	    {
	        $k[$i] = $cursor->getNext();
	      $i++;
	    }
	
	    // return $k;
    break;

    /*+
     * <znosql:update use="mongoDB">
     *   Commands
     * </znosql:execute>
     * 
     * Execute a NoSQL commands
     */ 
    case "update":
      $errorMessage .= ztagParamCheck($arrParam, "use");
      
      $this->collection->update($f1, $f2);
      break;

    /*+
     * <znosql:delete use="mongoDB">
     *   Commands
     * </znosql:execute>
     * 
     * Execute a NoSQL commands
     */ 
    case "delete":
      $errorMessage .= ztagParamCheck($arrParam, "use");
      
      $c = $this->collection->remove($f, $one);
      // return $c;
      break;
      
    /*+
     * <znosql:execute use="mongoDB">
     *   Commands
     * </znosql:execute>
     * 
     * Execute a NoSQL commands
     */ 
    case "execute":
      $errorMessage .= ztagParamCheck($arrParam, "use");

      // Execute Close, but I don't know yet!
      $arrayTagId[$strUse][ztagIdState] = idStateClosed;
      
    	// mongo->execute($cmd);
      break;
      
    /*+
     * <znosql:setdatabase use="mongoDB" database="Direito2" />
     * 
     * Set a database for current Opened NoSQL connection
     * 
     * use="mongoDB" 
     * database="Direito2"
     */ 
    case "setdatabase":
      $errorMessage .= ztagParamCheck($arrParam, "use,database");
          	
      if ($arrayTagId[$strUse][ztagIdType] === idTypeNoSQL) {
	      if ($arrayTagId[$strUse][ztagIdState] === idStateOpened) {
          $nosqlHandle = $arrayTagId[$strUse][ztagIdHandle];
          
          $dbHandle = $nosqlHandle[nosqlHandleId];

          try {
            $dbHandleDatabase = $dbHandle->selectDB($strDatabase);
            
            $nosqlHandle[nosqlHandleDatabaseName] = $strDatabase;
            $nosqlHandle[nosqlHandleDatabase]     = $dbHandleDatabase;
            
	        } catch(InvalidArgumentException $e) {
	          $errorMessage .= "<br />Invalid database name $strDatabase (".$e->getMessage().")[".$dbHandle->getLastError()."]";
	        }
          
          $arrayTagId[$strUse][ztagIdHandle] = $nosqlHandle;
	      	
	      } else {
	        $errorMessage .= "<br />The $strUse NoSQL handler is not Open!";
	      }
      } else {
      	$errorMessage .= "<br />The $strUse type is not a NoSQL!";
      }
      break;

    /*+
     * <znosql:listdatabases use="mongoDB" />
     * 
     * List all databases
     */ 
    case "listdatabases":
    	$dbs = $this->_db->selectDB('admin')->command(array('listDatabases' => 1));
			foreach ($dbs['databases'] as $db) {
        $return[$db['name']] = $db['name'] . ' ('
			                         . (!$db['empty'] ? round($db['sizeOnDisk'] / 1000000) . 'mb' : 'empty') . ')';
			}
			ksort($return);
			$dbCount = 0;
			foreach ($return as $key => $val) {
        $return[$key] = ++$dbCount . '. ' . $val;
			}
    	break;

    /*+
     * <znosql:getstats use="mongoDB" />
     * 
     * Return the server Stats
     */ 
    case "getstats":
      break;

    /*+
     * <znosql:repairdatabase use="mongoDB" preserveclonedfiles="true|false|1|0" backuporiginalfiles="true|false|1|0" />
     * 
     * Repair the Database
     * 
     *  preserveclonedfiles="true|false|1|0" 
     *  backuporiginalfiles="true|false|1|0"/>
     */ 
    case "repairdatabase":
    	$strPreserveClonedFiles = $arrParam["preserveclonedfiles"];
      $strBackupOriginalFiles = $arrParam["backuporiginalfiles"];
    	
      $errorMessage .= ztagParamCheck($arrParam, "use");
      
      if ($arrayTagId[$strUse][ztagIdType] === idTypeNoSQL) {
        if ($arrayTagId[$strUse][ztagIdState] === idStateOpened) {
          $nosqlHandle = $arrayTagId[$strUse][ztagIdHandle];

          if ($nosqlHandle[nosqlHandleDatabase]) {
            $strDatabase = $nosqlHandle[nosqlHandleDatabaseName];
            $dbHandleDatabase = $nosqlHandle[nosqlHandleDatabase];
  
            try {
            	if ($strPreserveClonedFiles === "true" || $strPreserveClonedFiles === "1") $strPreserveClonedFiles = true;
              if ($strBackupOriginalFiles === "true" || $strBackupOriginalFiles === "1") $strBackupOriginalFiles = true;
            	
            	if ($strPreserveClonedFiles && !$strBackupOriginalFiles) {
                $dbResult = $dbHandleDatabase->repair($strPreserveClonedFiles);
            	} elseif($strBackupOriginalFiles) {
            		$dbResult = $dbHandleDatabase->repair($strPreserveClonedFiles, $strBackupOriginalFiles);
            	} else {
            		$dbResult = $dbHandleDatabase->repair();
            	}
                                          
              if ($dbResult["ok"] != 1) {
                $errorMessage .= "<br />Cannot repair the $strDatabase <pre>".print_r($dbResult, 1)."</pre>";
              }
                            
            } catch(InvalidArgumentException $e) {
              $errorMessage .= "<br />Invalid collection name $strCollection at database $strDatabase (".$e->getMessage().")[".$dbHandle->getLastError().  "]";
            }
            
            $arrayTagId[$strUse][ztagIdHandle] = $nosqlHandle;
          
          } else {
            $errorMessage .= "<br />The $strUse NoSQL handler do not have a database defined!";
          }
        } else {
          $errorMessage .= "<br />The $strUse NoSQL handler is not Open!";
        }
      } else {
        $errorMessage .= "<br />The $strUse type is not a NoSQL!";
      }
      break;
      
    /*+
     * <znosql:dropdatabase use="mongoDB" />
     * 
     * Drop current database
     * 
     * use="mongoDB"
     */ 
    case "dropdatabase":
      $errorMessage .= ztagParamCheck($arrParam, "use");
      
      if ($arrayTagId[$strUse][ztagIdType] === idTypeNoSQL) {
        if ($arrayTagId[$strUse][ztagIdState] === idStateOpened) {
          $nosqlHandle = $arrayTagId[$strUse][ztagIdHandle];

          if ($nosqlHandle[nosqlHandleDatabase]) {
            $strDatabase = $nosqlHandle[nosqlHandleDatabaseName];
            $dbHandleDatabase = $nosqlHandle[nosqlHandleDatabase];
  
            try {
              $dbResult = $dbHandleDatabase->drop();
                                          
              if ($dbResult["ok"] == 1) {
	              $nosqlHandle[nosqlHandleDatabaseName] = null;
	              $nosqlHandle[nosqlHandleDatabase]     = null;
              } else {
              	$errorMessage .= "<br />Cannot drop the database $strDatabase <pre>".print_r($dbResult, 1)."</pre>";
              }
                            
            } catch(InvalidArgumentException $e) {
              $errorMessage .= "<br />Cannot drop the database $strDatabase (".$e->getMessage().")[".$dbHandle->getLastError().  "]";
            }
            
            $arrayTagId[$strUse][ztagIdHandle] = $nosqlHandle;
          
          } else {
            $errorMessage .= "<br />The $strUse NoSQL handler do not have a database defined!";
          }
        } else {
          $errorMessage .= "<br />The $strUse NoSQL handler is not Open!";
        }
      } else {
        $errorMessage .= "<br />The $strUse type is not a NoSQL!";
      }
      break;

    /*+
     * <znosql:setcollection use="mongoDB" collection="pubPaginas" />
     * 
     * Set a collection for current database
     * 
     *  use="mongoDB" 
     *  collection="pubPaginas"
     */ 
    case "setcollection":
      $errorMessage .= ztagParamCheck($arrParam, "use");
      
      if ($arrayTagId[$strUse][ztagIdType] === idTypeNoSQL) {
        if ($arrayTagId[$strUse][ztagIdState] === idStateOpened) {
        	$nosqlHandle = $arrayTagId[$strUse][ztagIdHandle];

        	if ($nosqlHandle[nosqlHandleDatabase]) {
	          $strDatabase = $nosqlHandle[nosqlHandleDatabaseName];
	          $dbHandleDatabase = $nosqlHandle[nosqlHandleDatabase];
	
	          try {
	            $dbHandleCollection = $dbHandleDatabase->selectCollection($strCollection);
	            
	            $nosqlHandle[nosqlHandleCollectionName] = $strCollection;
	            $nosqlHandle[nosqlHandleCollection]     = $dbHandleCollection;
	            	            
	          } catch(InvalidArgumentException $e) {
	            $errorMessage .= "<br />Invalid collection name $strCollection at database $strDatabase (".$e->getMessage().")[".$dbHandle->getLastError().  "]";
	          }
	          
	          $arrayTagId[$strUse][ztagIdHandle] = $nosqlHandle;
          
	        } else {
	          $errorMessage .= "<br />The $strUse NoSQL handler do not have a database defined!";
	        }
        } else {
          $errorMessage .= "<br />The $strUse NoSQL handler is not Open!";
        }
      } else {
        $errorMessage .= "<br />The $strUse type is not a NoSQL!";
      }
    	break;
      
    /*+
     * <znosql:listcollections use="mongoDB" />
     * 
     * List all collections for current database
     */ 
    case "listcollections":
        $collections = array();
        $MongoCollectionObjects = $this->mongo->listCollections();
        foreach ($MongoCollectionObjects as $collection) {
            $collection = substr(strstr((string) $collection, '.'), 1);
            $collections[$collection] = $this->mongo->selectCollection($collection)->count();
        }
        ksort($collections);
    	break;

    /*+
     * <znosql:dropcollection use="mongoDB" />
     * 
     * Drop a collection for current database
     * 
     * use="mongoDB"
     */ 
    case "dropcollection":
      $errorMessage .= ztagParamCheck($arrParam, "use");
      
      if ($arrayTagId[$strUse][ztagIdType] === idTypeNoSQL) {
        if ($arrayTagId[$strUse][ztagIdState] === idStateOpened) {
          $nosqlHandle = $arrayTagId[$strUse][ztagIdHandle];

          if ($nosqlHandle[nosqlHandleCollection]) {
            $strDatabase = $nosqlHandle[nosqlHandleDatabaseName];
          	$strCollection = $nosqlHandle[nosqlHandleCollectionName];
            $dbHandleCollection= $nosqlHandle[nosqlHandleCollection];
  
            try {
              $dbResult = $dbHandleCollection->drop();

              if ($dbResult["ok"] == 1) {
	              $nosqlHandle[nosqlHandleCollectionName] = null;
	              $nosqlHandle[nosqlHandleCollection]     = null;
              } else {
                $errorMessage .= "<br />Cannot drop the collection $strCollection at database $strDatabase  <pre>".print_r($dbResult, 1)."</pre>";
              }
                            
            } catch(InvalidArgumentException $e) {
              $errorMessage .= "<br />Cannot drop the collection $strCollection at database $strDatabase (".$e->getMessage().")[".$dbHandle->getLastError().  "]";
            }
            
            $arrayTagId[$strUse][ztagIdHandle] = $nosqlHandle;
          
          } else {
            $errorMessage .= "<br />The $strUse NoSQL handler do not have a database defined!";
          }
        } else {
          $errorMessage .= "<br />The $strUse NoSQL handler is not Open!";
        }
      } else {
        $errorMessage .= "<br />The $strUse type is not a NoSQL!";
      }
      break;

    /*+
     * <znosql:createcollection use="mongoDB" collection="pubPaginas" />
     * 
     * Create a collection for current database
     */ 
    case "createcollection":
      $errorMessage .= ztagParamCheck($arrParam, "use");
      
      if ($arrayTagId[$strUse][ztagIdType] === idTypeNoSQL) {
        if ($arrayTagId[$strUse][ztagIdState] === idStateOpened) {
          $nosqlHandle = $arrayTagId[$strUse][ztagIdHandle];

          if ($nosqlHandle[nosqlHandleDatabase]) {
            $strDatabase = $nosqlHandle[nosqlHandleDatabaseName];
            $dbHandleDatabase = $nosqlHandle[nosqlHandleDatabase];
  
            try {
              $dbHandleCollection = $dbHandleDatabase->createCollection($strCollection);
              
              $nosqlHandle[nosqlHandleCollectionName] = $strCollection;
              $nosqlHandle[nosqlHandleCollection]     = $dbHandleCollection;
                                          
            } catch(InvalidArgumentException $e) {
              $errorMessage .= "<br />Cannot create the collection $strCollection at database $strDatabase (".$e->getMessage().")[".$dbHandle->getLastError().  "]";
            }
            
            $arrayTagId[$strUse][ztagIdHandle] = $nosqlHandle;
          
          } else {
            $errorMessage .= "<br />The $strUse NoSQL handler do not have a database defined!";
          }
        } else {
          $errorMessage .= "<br />The $strUse NoSQL handler is not Open!";
        }
      } else {
        $errorMessage .= "<br />The $strUse type is not a NoSQL!";
      }
    	break;

    /*+
     * <znosql:createcollection use="mongoDB" from="pubPaginas" to="pubPaginasOld"/>
     * 
     * Create a collection for current database
     */ 
    case "renamecollection":
        $result = $this->_db->selectDB('admin')->command(array(
            'renameCollection' => $this->_dbName . '.' . $from,
            'to' => $this->_dbName . '.' . $to,
        ));
    	break;

    /*+
     * <znosql:listindexes use="mongoDB" collection="pubPaginas"/>
     * 
     * List all indexes for a Collection
     */ 
   case "listindexes":
    	return $this->mongo->selectCollection($collection)->getIndexInfo();
      break;

    /*+
     * <znosql:ensureindex use="mongoDB" collection="pubPaginas" index="pagNome"/>
     * 
     * Ensure a index for a Collection
     */ 
    case "ensureindex":
      $unique = ($unique ? true : false); //signature requires a bool in both Mongo v. 1.0.1 and 1.2.0
      // mongo->selectCollection($collection)->ensureIndex($indexes, $unique);
    	break;

    /*+
     * <znosql:deleteindex use="mongoDB" collection="pubPaginas" index="pagNome"/>
     * 
     * Delete a index for a Collection
     */ 
   case "deleteindex":
      // mongo->selectCollection($collection)->deleteIndex($index);
    	break;
      
    default:
      $errorMessage .= "<br />Undefined function \"$tagFunction\"";

  }

  ztagError($errorMessage, $arrayTag, $tagId);
}
