<?php
/**
 * zvar
 *
 * Processa as tags para gest�o das vari�veis do sistema.
 *
 * @package ztag
 * @subpackage var
 * @category Environment
 * @version 1.0
 * @author Ruben Zevallos Jr. <zevallos@zevallos.com.br>
 * @license http://www.gnu.org/licenses/gpl.html - GNU Public License
 * @copyright 2010 by Ruben Zevallos(r) Jr.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * This software consists of voluntary contributions made by many individuals
 * and is licensed under the GNU GPL. For more information, see
 * <http://http://code.google.com/p/ztag/>
 */

define("zvarVersion", 1.0, 1);
define("zvarVersionSufix", "ALFA 0.1", 1);

/**
 * Just to check if zTag was loaded
 *
 * <code>
 * zvar_exist();
 * </code>
 *
 * @return boolean 1 if exist
 *
 * @since 1.0
 */
function zvar_exist() {
  return 1;
}

/**
 * Return this zTag version
 *
 * <code>
 * zvar_version();
 * </code>
 *
 * @return string with zTag version
 *
 * @since 1.0
 */
function zvar_version() {
  return zvarVersion." ".zvarVersionSufix;
}

/**
 * Compare the version parameter with current version
 *
 * <code>
 * zvar_compare();
 * </code>
 *
 * @param number $version the version to compare
 *
 * @return boolean true if match with current version
 *
 * @since 1.0
 */
function zvar_compare($version) {
  return zvarVersion === $version;
}

/**
 * Main zTag functions selector
 *
 * <code>
 * zvar_execute($tagId, $tagFunction, $arrayTag, $arrayTagId, $arrayOrder);
 * </code>
 *
 * @param integer $tagId array id of current zTag of $arrayTag array
 * @param string $tagFunction name of zTag function
 * @param array $arrayTag array with all compiled zTags
 * @param array $arrayTagId array with all Ids values
 * @param array $arrayOrder array with zTag executing order
 *
 * @since 1.0
 */
function zvar_zexecute($tagId, $tagFunction, &$arrayTag, &$arrayTagId, $arrayOrder) {
  $arrParam = $arrayTag[$tagId][ztagParam];

  $strId    = $arrParam["id"];
  $strUse   = $arrParam["use"];
  $strVar   = $arrParam["var"];
  $strValue = $arrParam["value"];

  $errorMessage = "";

  switch (strtolower($tagFunction)) {
    case "set":
      $errorMessage .= ztagParamCheck($arrParam, "value");

      if (strlen($strVar)) $strId = $strVar;

    	$arrayTagId["$".$strId][ztagIdValue] = $strValue;
      $arrayTagId["$".$strId][ztagIdLength] = strlen($strValue);

    	$arrayTagId["$".$strId][ztagIdType] = idTypeFVar;

      break;

    // <zvar:setif use="getFiltro" equal="nome" var="sqlSelect" then="(SELECT CD_PESSOA FROM TB_ENDERECO_PESSOA WHERE NM_PESSOA LIKE '%$getFiltro%')" />
    // <zvar:setif use="CO_CPF" condition="empty()" var="sqlSelect" then="CO_CPF LIKE '%$CO_CPF%'" />
    case "setif":
      $strEqual        = $arrParam["equal"];
      $strNotEqual     = $arrParam["notequal"];
      $strThen         = $arrParam["then"];
      $strElse         = $arrParam["else"];
      $strCondition    = $arrParam["condition"];
      $strNotCondition = $arrParam["notcondition"];

    	$errorMessage .= ztagParamCheck($arrParam, "use,then,var");

    	if ($strUse) $strUse = $arrayTagId["$".$strUse][ztagIdValue];

      if ($strEqual) {
      	if ($strUse == $strEqual) {
          $arrayTagId["$".$strVar][ztagIdValue] = $strThen;
        } else {
	        if ($strElse) $arrayTagId["$".$strVar][ztagIdValue] = $strElse;
	      }
      }

      if ($strNotEqual) {
        if ($strUse != $strNotEqual) {
          $arrayTagId["$".$strVar][ztagIdValue] = $strThen;
        } else {
          if ($strElse) $arrayTagId["$".$strVar][ztagIdValue] = $strElse;
        }
      }

      if ($strCondition) {
      	$strCondition = ztagTransform($strUse, $strCondition);

        if ($strCondition) {
          $arrayTagId["$".$strVar][ztagIdValue] = $strThen;
        } else {
          if ($strElse) $arrayTagId["$".$strVar][ztagIdValue] = $strElse;
        }
      }

      if ($strNotCondition) {
        $strNotCondition = ztagTransform($strUse, $strNotCondition);

        if (!$strNotCondition) {
          $arrayTagId["$".$strVar][ztagIdValue] = $strThen;
        } else {
          if ($strElse) $arrayTagId["$".$strVar][ztagIdValue] = $strElse;
        }
      }
      break;

    case "unset":
    case "reset":
      $errorMessage = ztagParamCheck($arrParam, "use");

    	if ($arrayTagId["$".$strUse][ztagIdType] != idTypeFVar) $errorMessage .= "<br />The handle \"$strUse\" is not a var one!";

      $arrayTagId["$".$strUse] = array();
      break;

    case "get":
      $errorMessage = ztagParamCheck($arrParam, "use");

      if ($arrayTagId["$".$strUse][ztagIdType] != idTypeFVar) $errorMessage .= "<br />The handle \"$strUse\" is not a var one!";

      $strValue = $arrayTagId["$".$strUse][ztagIdValue];
      $arrayTag[$strVar][ztagResult] = $strValue;
    	break;

    case "show":
      $errorMessage = ztagParamCheck($arrParam, "use");

      if ($arrayTagId["$".$strUse][ztagIdType] != idTypeFVar) $errorMessage .= "<br />The handle \"$strUse\" is not a var one!";

      $strValue = $arrayTagId["$".$strUse][ztagIdValue];
      $arrayTag[$tagId][ztagResult] = $strValue;
      break;

    default:
      $errorMessage .= "<br />Undefined function \"$tagFunction\"";

  }

  /*
  debugError("tagFunction=$tagFunction"
            ."<br />tagId=$tagId"
            ."<br />strId=$strId"
            ."<br />strUse=$strUse"
            ."<br />strValue=$strValue"
            ."<br />arrayTagId[$strId][ztagIdValue]=".$arrayTagId[$strId][ztagIdValue]
            ."<br />arrayTagId[$strUse][ztagIdValue]=".$arrayTagId[$strUse][ztagIdValue]
            ."<br />arrayTag[$tagId][ztagResult]=".$arrayTag[$tagId][ztagResult]);
            */

  ztagError($errorMessage, $arrayTag, $tagId);
}

