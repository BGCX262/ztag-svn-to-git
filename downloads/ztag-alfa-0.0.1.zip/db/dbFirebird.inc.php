<?php
/**
 * dbFirebird
 *
 * Entrega fun��es de conex�o com base de dados firebird - Microsoft SQL
 *
 * @package db
 * @subpackage firebird
 * @version 1.0
 * @author Ruben Zevallos Jr. <zevallos@zevallos.com.br>
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @copyright 2007-2010 by Ruben Zevallos(r) Jr.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * This software consists of voluntary contributions made by many individuals
 * and is licensed under the LGPL. For more information, see
 * <http://ztag.zyc.com.br> *
 */

define("firebirdVersion", 1.0, 1);

/**
 * Retorna a vers�o do driver
 *
 * <code>
 * echo dbVersion_firebird
 * </code>
 *
 * @return float vers�o do driver
 *
 * @since Vers�o 1.0
 */
function dbVersion_firebird() {
  return firebirdVersion;
}

/**
 * Abra a conex�o com o banco de dados firebird
 *
 * <code>
 * $firebirdHandle = dbOpen_firebird("firebird", "database", "user", "password");
 * </code>
 *
 * @param string $dbHost string de conex�o com o banco de dados
 * @param string $dbDatabase[optional] string database utilizado
 * @param string $dbUser[optional] nome do usu�rio
 * @param string $dbPassword[optional] senha do usu�rio
 *
 * @return array com o handleId e o nome do driver
 *
 * @since Vers�o 1.0
 */

function dbOpen_firebird(&$dbHandle) {
  $debugBackTrace = debug_backtrace();

  $debugFile     = basename($debugBackTrace[1]["file"]);
  $debugFunction = $debugBackTrace[1]["function"];

  $dbDriver   = $dbHandle[dbHandleDriver];

  if(!function_exists("firebird_connect")) {
    echo "<span style=\"text-align: left;\"><pre><b>$dbDriver - $debugFile - $debugFunction() - Connect</b>:"
        ."<br />extension=<b>php_firebird.dll</b> is not loaded";

    echo "<hr />".debugBackTrace();

    echo "</pre></span>";
    die();
  }

  $dbDatabase = $dbHandle[dbHandleDatabase];
  $dbUser     = $dbHandle[dbHandleUser];
  $dbPassword = $dbHandle[dbHandlePassword];

  // @TODO Incluir tratamento para ver se o driver est� carregado
  if (!$firebirdConn = @ibase_connect($dbDatabase, $dbUser, $dbPassword)) {
    echo "<span style=\"text-align: left;\"><pre><b>$dbDriver - $debugFile - $debugFunction() - Connect</b>:"
        ."<br /><b>Database</b>: ".$dbDatabase
        ."<br /><b>Message</b>: [".ibase_errmsg()."]";

    echo "<hr />".debugBackTrace();

    echo "</pre></span>";
    die();
  }

  return $firebirdConn;
}

/**
 * Fecha uma conex�o previamente aberta com o banco de dados firebird
 *
 * <code>
 * dbClose_firebird($firebirdHandle);
 * </code>
 *
 * @param string $dbHandle handleId da conex�o
 *
 * @see dbOpen_OCI()
 *
 * @since Vers�o 1.0
 */

function dbClose_firebird(&$dbHandle) {
  // @TODO Incluir tratamento para ver se o driver est� carregado
  if ($dbHandle["dbHandleId"]) {
    ibase_close($dbHandle["dbHandleId"]);
  }
}

/**
 * Recupera uma linha de registro da conex�o em quest�o do firebird
 *
 * <code>
 * dbQuery_firebird($firebirdSQL);
 * </code>
 *
 * @param handle $dbQuery handleId da query firebird
 *
 * @see dbOpen_firebird()
 *
 * @since Vers�o 1.0
 */
function dbQuery_firebird(&$dbHandle, $dbSQL) {
  $debugBackTrace = debug_backtrace();

  $debugFile     = basename($debugBackTrace[1]["file"]);
  $debugFunction = $debugBackTrace[1]["function"];

  $dbHandleId = $dbHandle[dbHandleId];

  $dbDriver   = $dbHandle[dbHandleDriver];

  $dbDatabase = $dbHandle[dbHandleDatabase];

  if (!$firebirdQuery = @ibase_query($dbHandleId, $dbSQL)) {
    echo "<span style=\"text-align: left;\"><pre><b>$dbDriver - $debugFile - $debugFunction()</b>:"
        ."<br /><b>Database</b>: ".$dbDatabase
        ."<br /><b>Message</b>: [".ibase_errmsg()."]";

    echo "<hr />".debugBackTrace();

    echo "</pre></span>";
    die();
  }

  return $firebirdQuery;
}

/**
 * Recupera uma linha de registro da conex�o em quest�o do firebird
 *
 * <code>
 * dbFetch_firebird($firebirdQuery);
 * </code>
 *
 * @param handle $dbQuery handleId da query firebird
 *
 * @see dbOpen_firebird()
 *
 * @since Vers�o 1.0
 */
function dbFetch_firebird(&$dbHandle, $dbResultType=dbFetchBOTH) {
  $dbHandleQuery = $dbHandle[dbHandleQuery];

  $dbResultType .= "firebird_";

  if (defined($dbResultType)) {
    $dbResultType = constant($dbResultType);
  } else {
    $dbResultType = firebird_ASSOC;
  }

  if ($dbResultType === dbFetchNUM) {
    $firebirdFetch = ibase_fetch_row($dbHandleQuery);
  } else {
    $firebirdFetch = ibase_fetch_assoc($dbHandleQuery);
  }

  return $firebirdFetch;
}

?>